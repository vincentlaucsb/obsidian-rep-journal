/** Self-contained chart entry point. The renderer initializes lazily from compiled-in bytes. */
export { lineChart, barChart, heatmapChart, createLineRenderer } from "./line.js";
