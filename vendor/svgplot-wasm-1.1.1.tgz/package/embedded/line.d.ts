import type { BarChartOptions, HeatmapOptions, LineChartOptions, MultiLineOptions } from "./chart-types.js";
export type * from "./chart-types.js";
export interface LineRenderer {
    /** Render one series from interleaved x, y coordinates using svgplot defaults. */
    renderLine(coordinates: Float64Array): string;
    /** Mount a single-series SVG and retain its nodes for subsequent updates. */
    mountLine(host: HTMLElement, coordinates: Float64Array): MountedLine;
}
export interface MountedLine {
    readonly svg: SVGSVGElement;
    update(coordinates: Float64Array): void;
}
export interface SvgplotInitializationOptions {
    /** Supply local bytes for embedded applications, such as a CommonJS plugin. */
    wasmBinary?: Uint8Array;
    /** Override the URL of the WebAssembly asset in a browser deployment. */
    wasmUrl?: string;
}
/** Optionally configure the shared engine before the first chart is drawn. */
export declare function initializeSvgplot(options?: SvgplotInitializationOptions): Promise<void>;
/** Draw one or more lines, retaining series paths and their markers across redraws. */
export declare function lineChart(target: string | HTMLElement, options: LineChartOptions | MultiLineOptions): Promise<SVGSVGElement>;
export declare function barChart(target: string | HTMLElement, options: BarChartOptions): Promise<SVGSVGElement>;
export declare function heatmapChart(target: string | HTMLElement, options: HeatmapOptions): Promise<SVGSVGElement>;
export declare function createLineRenderer(): Promise<LineRenderer>;
