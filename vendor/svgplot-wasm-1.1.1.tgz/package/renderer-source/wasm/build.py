"""Build the optional browser module using the active Emscripten SDK."""

import argparse
import base64
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--svg-include", type=Path, default=root / "third_party" / "svg",
                    help="directory containing the svg.hpp backend")
args = parser.parse_args()
if not (args.svg_include / "svg.hpp").is_file():
    parser.error("pass --svg-include pointing to the directory containing svg.hpp")
print(f"svgplot backend: {(args.svg_include / 'svg.hpp').resolve()}", flush=True)
compiler = shutil.which("em++")
if compiler is None:
    parser.error("activate an Emscripten SDK to put em++ on PATH")
out = root / "out" / "wasm-line"
out.mkdir(parents=True, exist_ok=True)
embedded = out / "embedded"
embedded.mkdir(exist_ok=True)
build = [compiler, "-std=c++23", "-O3", "-DNDEBUG", "-fwasm-exceptions", "-lembind",
         "-sMODULARIZE=1", "-sENVIRONMENT=web", "-sALLOW_MEMORY_GROWTH=1", "-sDYNAMIC_EXECUTION=0",
         "-I", root / "include", "-I", args.svg_include, root / "wasm" / "line.cpp"]
subprocess.run([*build, "-o", out / "line-engine.mjs"], check=True)
subprocess.run([*build, "-sSINGLE_FILE=1", "-sSINGLE_FILE_BINARY_ENCODE=0", "--closure", "1",
                "-o", embedded / "line-engine.mjs"], check=True)
# Both entry points must carry the same compiled renderer.
if base64.b64encode((out / "line-engine.wasm").read_bytes()) not in (embedded / "line-engine.mjs").read_bytes():
    raise RuntimeError("Embedded renderer differs from line-engine.wasm")
subprocess.run([
    "node", root / "node_modules/typescript/bin/tsc", "--strict", "--target", "ES2022",
    "--module", "NodeNext", "--declaration", "--outDir", out, root / "wasm/charts.ts", root / "wasm/embedded.ts",
], check=True)
# Resolve the shared chart implementation's relative engine import to the chosen loader.
for name in ("line.js", "line.d.ts", "chart-types.d.ts"):
    shutil.copyfile(out / name, embedded / name)
for extension in ("js", "d.ts"):
    shutil.copyfile(out / f"embedded.{extension}", embedded / f"index.{extension}")
