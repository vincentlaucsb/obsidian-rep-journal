#pragma once

#include "../core/bounds.hpp"
#include "../core/layout.hpp"
#include "../scale.hpp"
#include "types.hpp"

#include <vector>

namespace svgplot::detail {

inline LinearScale bar_y_scale(double maximum, TickMode mode, int ticks, const ChartLayout& layout) {
    const auto upper = std::max(0.0, maximum) * 1.1;
    Bounds domain{0.0, upper == 0.0 ? 1.0 : upper};
    if (mode == TickMode::Integer) domain = LinearScale::nice_integer_domain(domain, ticks);
    return LinearScale(domain, {layout.plot_bottom, layout.plot_top});
}

inline double bar_top(const LinearScale& scale, double value) {
    return scale.map(std::max(0.0, value));
}

inline bool integral_bar_values(const std::vector<Bar>& bars) {
    for (const auto& bar : bars) {
        if (!integral_value(bar.value)) {
            return false;
        }
    }
    return !bars.empty();
}

} // namespace svgplot::detail
