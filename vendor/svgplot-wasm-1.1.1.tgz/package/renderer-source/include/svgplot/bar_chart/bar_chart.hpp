#pragma once

#include "../chart.hpp"
#include "../core/colors.hpp"
#include "../core/format.hpp"
#include "../core/layout.hpp"
#include "../core/palette.hpp"
#include "../core/rendering.hpp"
#include "../core/styles.hpp"
#include "../core/svg_backend.hpp"
#include "../legend/legend.hpp"
#include "../scale.hpp"
#include "../types.hpp"
#include "bounds.hpp"
#include "styles.hpp"
#include "types.hpp"

#include <algorithm>
#include <cstddef>
#include <initializer_list>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace svgplot {

class BarChart {
public:
    BarChart& bar(std::string label,
                  double value,
                  std::string color = {}) {
        if (!stacks_.empty() || !groups_.empty()) {
            throw std::invalid_argument("bar chart cannot mix simple, stacked, and grouped bars");
        }
        bars_.push_back({std::move(label), value, std::move(color)});
        return *this;
    }

    BarChart& bar(Bar bar) {
        if (!stacks_.empty() || !groups_.empty()) {
            throw std::invalid_argument("bar chart cannot mix simple, stacked, and grouped bars");
        }
        bars_.push_back(std::move(bar));
        return *this;
    }

    BarChart& stacked_bar(std::string label, std::vector<BarSegment> segments) {
        if (!bars_.empty() || !groups_.empty()) {
            throw std::invalid_argument("bar chart cannot mix simple, stacked, and grouped bars");
        }
        stacks_.push_back({std::move(label), std::move(segments)});
        return *this;
    }

    BarChart& stacked_bar(std::string label, std::initializer_list<BarSegment> segments) {
        return stacked_bar(std::move(label), std::vector<BarSegment>(segments));
    }

    BarChart& grouped_bar(std::string label, std::vector<BarSegment> segments) {
        if (!bars_.empty() || !stacks_.empty()) {
            throw std::invalid_argument("bar chart cannot mix simple, stacked, and grouped bars");
        }
        groups_.push_back({std::move(label), std::move(segments)});
        return *this;
    }

    BarChart& grouped_bar(std::string label, std::initializer_list<BarSegment> segments) {
        return grouped_bar(std::move(label), std::vector<BarSegment>(segments));
    }

    [[nodiscard]] Chart render(ChartOptions options = {}) const {
        if (!groups_.empty()) {
            return render_grouped(std::move(options));
        }
        if (!stacks_.empty()) {
            return render_stacked(std::move(options));
        }
        if (bars_.empty()) {
            throw std::invalid_argument("bar chart requires at least one bar");
        }

        SVG::SVG root(SVG::SVGAttrib{{"xmlns", "http://www.w3.org/2000/svg"}});

        detail::add_common_styles(root);
        detail::add_bar_chart_styles(root);
        detail::add_responsive_chart_root_attrs(root, options, "Bar chart");

        auto& frame = *root.add_child<SVG::Group>();
        auto& plot = *frame.add_child<SVG::SVG>(SVG::SVGAttrib{{"x", "0"}, {"y", "0"}});
        detail::add_axis_labels(plot, options);

        const std::vector<LegendItem> legend_items;
        const auto layout = detail::chart_layout(options);
        const auto legend_layout = detail::measure_legend(legend_items, options.legend);

        const auto max_it = std::max_element(bars_.begin(), bars_.end(), [](const Bar& a, const Bar& b) {
            return a.value < b.value;
        });
        const auto y_tick_mode = detail::resolve_tick_mode(options.y_tick_mode,
                                                           detail::integral_bar_values(bars_));
        const auto y_scale = detail::bar_y_scale(max_it->value, y_tick_mode, options.y_ticks, layout);
        detail::add_axes(plot, options, layout,
                         LinearScale({0.0, static_cast<double>(bars_.size()) - 1.0},
                                     {layout.plot_left, layout.plot_right}),
                         y_scale, y_tick_mode, false);

        const auto plot_width = layout.plot_right - layout.plot_left;
        const auto slot = plot_width / static_cast<double>(bars_.size());
        const auto bar_width = slot * 0.64;
        const auto baseline = y_scale.map(0.0);

        detail::CssColorRegistry colors(detail::core_css_vars(root));
        for (std::size_t i = 0; i < bars_.size(); ++i) {
            const auto left = layout.plot_left + slot * static_cast<double>(i) + (slot - bar_width) / 2.0;
            const auto top = detail::bar_top(y_scale, bars_[i].value);
            const auto color_class = colors.class_for(
                root, detail::palette::series_color(bars_[i].color, i));
            auto* rect = plot.add_child<SVG::Rect>(left, top, bar_width, baseline - top);
            rect->class_list().add("bar").add(color_class);

            auto* label = plot.add_child<SVG::Text>(left + bar_width / 2.0, baseline + 20.0, bars_[i].label);
            detail::style_text(label, 11.0);
            label->set_attr("class", "bar-label");
        }

        detail::autoscale_svg_region(plot);
        const auto legend_place = detail::place_legend(
            detail::svg_region_layout(plot), legend_layout, options.legend, 0.0);
        detail::add_legend(frame, root, colors, legend_items, options.legend,
                           legend_place.x, legend_place.y, legend_place.max_width);
        frame.layout_bbox(plot.layout_bbox() + detail::legend_bbox(legend_layout, legend_place));
        detail::add_chart_title(root, options, frame);
        root.responsive_autoscale(SVG::AutoscaleOptions({8, 8, 8, 8}, false));

        return Chart(std::move(root));
    }

    // Source indices in SVG rectangle order, counting input segments row by row.
    // Grouped bars may reorder by series label; nonpositive segments have no rectangle.
    [[nodiscard]] std::pair<Chart, std::vector<std::size_t>> render_indexed_segments(ChartOptions options = {}) const {
        std::vector<std::size_t> indices;
        if (groups_.empty() && stacks_.empty()) throw std::invalid_argument("segmented chart requires at least one category");
        auto chart = groups_.empty() ? render_stacked(std::move(options), &indices)
                                     : render_grouped(std::move(options), &indices);
        return {std::move(chart), std::move(indices)};
    }

private:
    struct SegmentedBar {
        std::string label;
        std::vector<BarSegment> segments;
    };

    static std::vector<LegendItem> segment_legend_items(const std::vector<SegmentedBar>& bars) {
        const auto series_order = segment_series_order(bars);
        const auto series_colors = segment_series_colors(bars, series_order);
        std::vector<LegendItem> legend_items;
        legend_items.reserve(series_order.size());
        for (std::size_t i = 0; i < series_order.size(); ++i) {
            legend_items.push_back({series_order[i], series_colors[i], "", LegendMarker::Bar});
        }
        if (legend_items.size() <= 1) {
            legend_items.clear();
        }
        return legend_items;
    }

    static std::vector<std::string> segment_series_order(const std::vector<SegmentedBar>& bars) {
        std::vector<std::string> labels;
        std::set<std::string> seen;
        for (const auto& bar : bars) {
            for (const auto& segment : bar.segments) {
                if (segment.label.empty()) {
                    continue;
                }
                if (seen.insert(segment.label).second) {
                    labels.push_back(segment.label);
                }
            }
        }
        return labels;
    }

    static std::vector<std::string> segment_series_colors(const std::vector<SegmentedBar>& bars,
                                                          const std::vector<std::string>& series_order) {
        std::vector<std::string> colors;
        colors.reserve(series_order.size());
        for (std::size_t i = 0; i < series_order.size(); ++i) {
            std::string color;
            for (const auto& bar : bars) {
                const auto found = std::find_if(bar.segments.begin(), bar.segments.end(),
                                                [&](const BarSegment& segment) {
                                                    return segment.label == series_order[i] &&
                                                           !segment.color.empty();
                                                });
                if (found != bar.segments.end()) {
                    color = found->color;
                    break;
                }
            }
            colors.push_back(detail::palette::series_color(color, i));
        }
        return colors;
    }

    static std::string segment_color(const BarSegment& segment,
                                     std::size_t segment_index,
                                     const std::vector<std::string>& series_order,
                                     const std::vector<std::string>& series_colors) {
        if (!segment.color.empty()) {
            return segment.color;
        }
        const auto found = std::find(series_order.begin(), series_order.end(), segment.label);
        if (found != series_order.end()) {
            return series_colors[static_cast<std::size_t>(found - series_order.begin())];
        }
        return default_series_color(segment_index);
    }

    static bool all_segments_labeled(const std::vector<SegmentedBar>& bars) {
        for (const auto& bar : bars) {
            for (const auto& segment : bar.segments) {
                if (segment.label.empty()) {
                    return false;
                }
            }
        }
        return true;
    }

    static const BarSegment* grouped_segment_at(const SegmentedBar& bar,
                                                std::size_t index,
                                                const std::vector<std::string>& series_order,
                                                bool align_by_label) {
        if (!align_by_label) {
            return index < bar.segments.size() ? &bar.segments[index] : nullptr;
        }

        for (const auto& segment : bar.segments) {
            if (segment.label == series_order[index]) {
                return &segment;
            }
        }
        return nullptr;
    }

    [[nodiscard]] Chart render_stacked(ChartOptions options, std::vector<std::size_t>* indices = nullptr) const {
        SVG::SVG root(SVG::SVGAttrib{{"xmlns", "http://www.w3.org/2000/svg"}});

        detail::add_common_styles(root);
        detail::add_bar_chart_styles(root);
        detail::add_responsive_chart_root_attrs(root, options, "Bar chart");

        auto& frame = *root.add_child<SVG::Group>();
        auto& plot = *frame.add_child<SVG::SVG>(SVG::SVGAttrib{{"x", "0"}, {"y", "0"}});
        detail::add_axis_labels(plot, options);

        const auto legend_items = segment_legend_items(stacks_);
        const auto series_order = segment_series_order(stacks_);
        const auto series_colors = segment_series_colors(stacks_, series_order);
        const auto layout = detail::chart_layout(options);
        const auto legend_layout = detail::measure_legend(legend_items, options.legend);

        double y_max = 0.0;
        bool integral_values = true;
        for (const auto& stack : stacks_) {
            double total = 0.0;
            for (const auto& segment : stack.segments) {
                if (!detail::integral_value(segment.value)) {
                    integral_values = false;
                }
                total += std::max(0.0, segment.value);
            }
            y_max = std::max(y_max, total);
        }
        const auto y_tick_mode = detail::resolve_tick_mode(options.y_tick_mode, integral_values);
        const auto y_scale = detail::bar_y_scale(y_max, y_tick_mode, options.y_ticks, layout);
        detail::add_axes(plot, options, layout,
                         LinearScale({0.0, static_cast<double>(stacks_.size()) - 1.0},
                                     {layout.plot_left, layout.plot_right}),
                         y_scale, y_tick_mode, false);

        const auto plot_width = layout.plot_right - layout.plot_left;
        const auto slot = plot_width / static_cast<double>(stacks_.size());
        const auto bar_width = slot * 0.64;
        const auto baseline = y_scale.map(0.0);

        detail::CssColorRegistry colors(detail::core_css_vars(root));
        std::size_t offset = 0;
        for (std::size_t i = 0; i < stacks_.size(); ++i) {
            const auto left = layout.plot_left + slot * static_cast<double>(i) + (slot - bar_width) / 2.0;
            double cumulative = 0.0;
            for (std::size_t j = 0; j < stacks_[i].segments.size(); ++j) {
                const auto& segment = stacks_[i].segments[j];
                const auto value = std::max(0.0, segment.value);
                if (value == 0.0) {
                    continue;
                }

                const auto top_value = cumulative + value;
                const auto top = y_scale.map(top_value);
                const auto bottom = y_scale.map(cumulative);
                const auto color_class = colors.class_for(
                    root, segment_color(segment, j, series_order, series_colors));
                auto* rect = plot.add_child<SVG::Rect>(left, top, bar_width, bottom - top);
                rect->class_list().add("bar").add("bar-segment").add(color_class);
                if (indices) indices->push_back(offset + j);
                cumulative = top_value;
            }
            offset += stacks_[i].segments.size();

            auto* label = plot.add_child<SVG::Text>(left + bar_width / 2.0,
                                                    baseline + 20.0,
                                                    stacks_[i].label);
            detail::style_text(label, 11.0);
            label->set_attr("class", "bar-label");
        }

        detail::autoscale_svg_region(plot);
        const auto legend_place = detail::place_legend(
            detail::svg_region_layout(plot), legend_layout, options.legend, 0.0);
        detail::add_legend(frame, root, colors, legend_items, options.legend,
                           legend_place.x, legend_place.y, legend_place.max_width);
        frame.layout_bbox(plot.layout_bbox() + detail::legend_bbox(legend_layout, legend_place));
        detail::add_chart_title(root, options, frame);
        root.responsive_autoscale(SVG::AutoscaleOptions({8, 8, 8, 8}, false));

        return Chart(std::move(root));
    }

    [[nodiscard]] Chart render_grouped(ChartOptions options, std::vector<std::size_t>* indices = nullptr) const {
        SVG::SVG root(SVG::SVGAttrib{{"xmlns", "http://www.w3.org/2000/svg"}});

        detail::add_common_styles(root);
        detail::add_bar_chart_styles(root);
        detail::add_responsive_chart_root_attrs(root, options, "Bar chart");

        auto& frame = *root.add_child<SVG::Group>();
        auto& plot = *frame.add_child<SVG::SVG>(SVG::SVGAttrib{{"x", "0"}, {"y", "0"}});
        detail::add_axis_labels(plot, options);

        const auto series_order = segment_series_order(groups_);
        const auto series_colors = segment_series_colors(groups_, series_order);
        const auto legend_items = segment_legend_items(groups_);
        const auto align_by_label = !series_order.empty() && all_segments_labeled(groups_);
        std::size_t bars_per_group = align_by_label ? series_order.size() : 0;
        if (!align_by_label) {
            for (const auto& group : groups_) {
                bars_per_group = std::max(bars_per_group, group.segments.size());
            }
        }
        bars_per_group = std::max<std::size_t>(1, bars_per_group);

        const auto layout = detail::chart_layout(options);
        const auto legend_layout = detail::measure_legend(legend_items, options.legend);

        double y_max = 0.0;
        bool integral_values = true;
        for (const auto& group : groups_) {
            for (const auto& segment : group.segments) {
                if (!detail::integral_value(segment.value)) {
                    integral_values = false;
                }
                y_max = std::max(y_max, std::max(0.0, segment.value));
            }
        }
        const auto y_tick_mode = detail::resolve_tick_mode(options.y_tick_mode, integral_values);
        const auto y_scale = detail::bar_y_scale(y_max, y_tick_mode, options.y_ticks, layout);
        detail::add_axes(plot, options, layout,
                         LinearScale({0.0, static_cast<double>(groups_.size()) - 1.0},
                                     {layout.plot_left, layout.plot_right}),
                         y_scale, y_tick_mode, false);

        const auto plot_width = layout.plot_right - layout.plot_left;
        const auto slot = plot_width / static_cast<double>(groups_.size());
        const auto group_width = slot * 0.72;
        const auto bar_gap = bars_per_group > 1
            ? group_width * 0.08 / static_cast<double>(bars_per_group - 1)
            : 0.0;
        const auto bar_width = (group_width - bar_gap * static_cast<double>(bars_per_group - 1)) /
                               static_cast<double>(bars_per_group);
        const auto baseline = y_scale.map(0.0);

        detail::CssColorRegistry colors(detail::core_css_vars(root));
        std::size_t offset = 0;
        for (std::size_t i = 0; i < groups_.size(); ++i) {
            const auto group_left = layout.plot_left + slot * static_cast<double>(i) +
                                    (slot - group_width) / 2.0;
            for (std::size_t j = 0; j < bars_per_group; ++j) {
                const auto* segment = grouped_segment_at(groups_[i], j, series_order, align_by_label);
                if (segment == nullptr) {
                    continue;
                }

                const auto value = std::max(0.0, segment->value);
                if (value == 0.0) {
                    continue;
                }

                const auto left = group_left + static_cast<double>(j) * (bar_width + bar_gap);
                const auto top = y_scale.map(value);
                const auto color_class = colors.class_for(
                    root, segment_color(*segment, j, series_order, series_colors));
                auto* rect = plot.add_child<SVG::Rect>(left, top, bar_width, baseline - top);
                rect->class_list().add("bar").add("bar-grouped").add(color_class);
                if (indices) indices->push_back(offset + static_cast<std::size_t>(segment - groups_[i].segments.data()));
            }
            offset += groups_[i].segments.size();

            auto* label = plot.add_child<SVG::Text>(layout.plot_left + slot * (static_cast<double>(i) + 0.5),
                                                    baseline + 20.0,
                                                    groups_[i].label);
            detail::style_text(label, 11.0);
            label->set_attr("class", "bar-label");
        }

        detail::autoscale_svg_region(plot);
        const auto legend_place = detail::place_legend(
            detail::svg_region_layout(plot), legend_layout, options.legend, 0.0);
        detail::add_legend(frame, root, colors, legend_items, options.legend,
                           legend_place.x, legend_place.y, legend_place.max_width);
        frame.layout_bbox(plot.layout_bbox() + detail::legend_bbox(legend_layout, legend_place));
        detail::add_chart_title(root, options, frame);
        root.responsive_autoscale(SVG::AutoscaleOptions({8, 8, 8, 8}, false));

        return Chart(std::move(root));
    }

    std::vector<Bar> bars_;
    std::vector<SegmentedBar> stacks_;
    std::vector<SegmentedBar> groups_;
};

inline Chart bar_chart(const std::vector<Bar>& bars, ChartOptions options = {}) {
    BarChart chart;
    for (const auto& item : bars) {
        chart.bar(item);
    }
    return chart.render(std::move(options));
}

} // namespace svgplot
